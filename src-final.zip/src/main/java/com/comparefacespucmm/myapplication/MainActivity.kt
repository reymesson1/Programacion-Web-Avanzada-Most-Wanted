package com.comparefacespucmm.myapplication

import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.util.Log
import com.amazonaws.mobile.client.AWSMobileClient
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.services.s3.AmazonS3Client
import com.comparefacespucmm.myapplication.Model.Master
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    val REQUEST_IMAGE_CAPTURE = 1
    var currentPhotoPath: String = ""
    val REQUEST_TAKE_PHOTO = 1
    var wholeName = ""
    var wholeDir= ""
    var LOG_TAG = ""

    var rest = RestAPI()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btn_take.setOnClickListener {
            dispatchTakePictureIntent()
        }

        btn_aws.setOnClickListener {

            AWSMobileClient.getInstance().initialize(this).execute()
            uploadWithTransferUtility()




        }

        btn_submit.setOnClickListener {

            rest.setMasterAPI("test")
        }

        btn_compare.setOnClickListener {

            doAsync {


                Thread.sleep(2000)

                activityUiThread {


                    getData()


                }

            }

        }

    }

    fun getData(){

        var masterService = rest.getMasterAPI()

        var call = masterService.getMaster()

        call.enqueue(object : Callback<List<Master>> {
            override fun onFailure(call: Call<List<Master>>, t: Throwable) {
                Log.i("error", t.toString())
            }

            override fun onResponse(call: Call<List<Master>>, response: Response<List<Master>>) {

                var str = ""

                response.body()!!.forEach {at ->

                    Log.i("response", at.description)

                    str += at.description

                }

                nameTXT.setText(str)


            }

        })

    }

    fun uploadWithTransferUtility() {
        val transferUtility = TransferUtility.builder()
            .context(this.applicationContext)
            .awsConfiguration(AWSMobileClient.getInstance().configuration)
            .s3Client(AmazonS3Client(AWSMobileClient.getInstance().credentialsProvider))
            .build()


        File(
            Environment
                .getExternalStorageDirectory().toString(), "/Android/data/com.comparefacespucmm.myapplication/files/Pictures/"
        ).walkTopDown().forEachIndexed { index, at->

            Log.i("response", at.name)

            if(index>0){

                //            val uploadObserver = transferUtility.upload("PUCMM.jpg", File("/storage/emulated/0/Android/data/com.comparefacespucmm.myapplication/files/Pictures/PUCMM.jpg"))
                val uploadObserver = transferUtility.upload(at.name, File("/storage/emulated/0/Android/data/com.comparefacespucmm.myapplication/files/Pictures/"+at.name))


                // Attach a listener to the observer
                uploadObserver.setTransferListener(object : TransferListener {
                    override fun onStateChanged(id: Int, state: TransferState) {
                        if (state == TransferState.COMPLETED) {
                            // Handle a completed upload
                        }
                    }

                    override fun onProgressChanged(id: Int, current: Long, total: Long) {
                        val done = (((current.toDouble() / total) * 100.0).toInt())
                        Log.d(LOG_TAG, "UPLOAD - - ID: $id, percent done = $done")
                    }

                    override fun onError(id: Int, ex: Exception) {
                        Log.d(LOG_TAG, "UPLOAD ERROR - - ID: $id - - EX: ${ex.message.toString()}")
                    }
                })

                // If you prefer to long-poll for updates
                if (uploadObserver.state == TransferState.COMPLETED) {
                    /* Handle completion */
                }

                val bytesTransferred = uploadObserver.bytesTransferred

            }



        }




    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        Log.i("pucmm", storageDir.toString() +"/PUCMM_"+timeStamp+".jpg ")
        Log.i("pucmm", currentPhotoPath)
        wholeDir = storageDir.toString() +"/PUCMM.jpg "
        wholeName = "PUCMM.jpg "
        return File(
            storageDir,
            "PUCMM.jpg"
        )

//        return File.createTempFile(
//            "PUCMM_123", /* prefix */
////            "PUCMM_${timeStamp}_", /* prefix */
//            ".jpg", /* suffix */
//            storageDir /* directory */
//        ).apply {
//            // Save a file: path for use with ACTION_VIEW intents
//            currentPhotoPath = absolutePath
//        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    // Error occurred while creating the File
                    null
                }
                // Continue only if the File was successfully created
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "com.example.android.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO)
                }
            }
        }
    }

}
