package com.comparefacespucmm.myapplication.Model

class Master{

    var id : String = ""
    var description : String = ""
    var project : String = ""
    var username : String = ""
    var quantity : String = ""
}