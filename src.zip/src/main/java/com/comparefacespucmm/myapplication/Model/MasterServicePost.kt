package com.comparefacespucmm.myapplication.Model

import org.json.JSONObject
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Call

interface MasterServicePost{

    @POST("https://xztyb8lrzk.execute-api.us-east-1.amazonaws.com/live/setcompare")

    fun setMaster(@Body data : JSONObject) : Call<String>

}